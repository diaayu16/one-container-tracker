# One Container Tracker

Aplikasi dashboard simulasi untuk mencatat dan melacak status kontainer. Dibuat menggunakan HTML, CSS, dan JavaScript tanpa framework atau instalasi tambahan.

## Fitur
- Dashboard ringkasan total kontainer, transit, tiba, dan tertunda
- Pencarian berdasarkan nomor kontainer, rute, kapal, lokasi, atau status
- Filter status dan pengurutan data
- Tambah, edit, dan hapus data kontainer
- Ekspor data ke CSV
- Penyimpanan data di browser menggunakan `localStorage`
- Tampilan responsif untuk desktop dan ponsel

## Menjalankan di komputer
1. Unduh `index.html`.
2. Klik dua kali file `index.html` untuk membukanya di browser.

## Mengunggah ke GitHub
1. Masuk ke GitHub dan buat repository baru bernama `one-container-tracker`.
2. Pilih **Add file → Upload files**.
3. Unggah `index.html` dan `README.md`.
4. Klik **Commit changes**.
5. Buka **Settings → Pages**.
6. Pada **Build and deployment**, pilih **Deploy from a branch**.
7. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
8. Tunggu proses deployment, lalu buka URL yang ditampilkan pada halaman GitHub Pages.

## Catatan penting
Ini adalah proyek portofolio/demo dengan data contoh. Status lokasi tidak berasal dari pelacakan kapal atau API perusahaan pelayaran secara real-time. Data disimpan di browser yang digunakan, bukan database bersama. Untuk penggunaan produksi, tambahkan backend, autentikasi, database, validasi, dan integrasi API resmi.

## Contoh deskripsi portofolio
Developed a responsive container tracking dashboard using HTML, CSS, and JavaScript. Implemented shipment status monitoring, container search and filtering, CRUD operations, local browser storage, and CSV export to support logistics data administration.
